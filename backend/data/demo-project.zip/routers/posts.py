from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database import get_db
import models

router = APIRouter()

@router.post("/")
def create_post(title: str, content: str, author_id: int, db: Session = Depends(get_db)):
    post = models.Post(title=title, content=content, author_id=author_id)
    db.add(post)
    db.commit()
    db.refresh(post)
    return post

@router.get("/")
def list_posts(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    return db.query(models.Post).offset(skip).limit(limit).all()

@router.get("/{post_id}")
def get_post(post_id: int, db: Session = Depends(get_db)):
    post = db.query(models.Post).filter(models.Post.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="게시물을 찾을 수 없습니다.")
    return post

@router.put("/{post_id}")
def update_post(post_id: int, title: str, content: str, current_user_id: int, db: Session = Depends(get_db)):
    post = db.query(models.Post).filter(models.Post.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="게시물을 찾을 수 없습니다.")
    if post.author_id != current_user_id:
        raise HTTPException(status_code=403, detail="권한이 없습니다.")
    post.title = title
    post.content = content
    db.commit()
    return post

@router.delete("/{post_id}")
def delete_post(post_id: int, current_user_id: int, db: Session = Depends(get_db)):
    post = db.query(models.Post).filter(models.Post.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="게시물을 찾을 수 없습니다.")
    if post.author_id != current_user_id:
        raise HTTPException(status_code=403, detail="권한이 없습니다.")
    db.delete(post)
    db.commit()
    return {"ok": True}
