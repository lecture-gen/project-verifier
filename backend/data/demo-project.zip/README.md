# 데모: FastAPI REST API 프로젝트

## 프로젝트 개요
FastAPI와 SQLite3를 사용해 사용자 인증 및 게시물 CRUD API를 구현한 프로젝트입니다.

## 기술 스택
- Python 3.11
- FastAPI 0.110
- SQLAlchemy 2.x
- SQLite3
- JWT 인증 (python-jose)
- bcrypt 비밀번호 해싱

## 주요 기능
- 사용자 회원가입 / 로그인 (JWT)
- 게시물 CRUD (생성, 조회, 수정, 삭제)
- 페이지네이션
- 권한 검사 (작성자만 수정/삭제 가능)

## 실행 방법
```bash
pip install -r requirements.txt
uvicorn main:app --reload
```
