from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routers import auth, posts
from database import engine, Base

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Demo Blog API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix="/auth", tags=["auth"])
app.include_router(posts.router, prefix="/posts", tags=["posts"])

@app.get("/health")
def health():
    return {"status": "ok"}
